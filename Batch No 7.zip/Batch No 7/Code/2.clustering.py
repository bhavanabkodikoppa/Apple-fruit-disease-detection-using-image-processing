import cv2
import numpy as np

from sklearn.cluster import KMeans

img=cv2.imread('apple (11).jpg')
#cv2.imshow('original',img)
image=cv2.cvtColor(img,cv2.COLOR_BGR2LAB)
#cv2.imshow('original',lab)
reshaped = image.reshape(image.shape[0] * image.shape[1], image.shape[2])



numClusters = max(2, 3)
kmeans = KMeans(n_clusters=numClusters, n_init=40, max_iter=500).fit(reshaped)
clustering = np.reshape(np.array(kmeans.labels_, dtype=np.uint8),
    (image.shape[0], image.shape[1]))
sortedLabels = sorted([n for n in range(numClusters)],
    key=lambda x: -np.sum(clustering == x))
kmeansImage = np.zeros(image.shape[:2], dtype=np.uint8)
for i, label in enumerate(sortedLabels):
    kmeansImage[clustering == label] = int((255) / (numClusters - 1)) * i
concatImage = np.concatenate((img,
    193 * np.ones((img.shape[0], int(0.0625 * img.shape[1]), 3), dtype=np.uint8),
    cv2.cvtColor(kmeansImage, cv2.COLOR_GRAY2BGR)), axis=1)
cv2.imshow('Original vs clustered', concatImage)




