from sklearn import svm, datasets
import sklearn.model_selection as model_selection
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
import pandas as pd
import csv

with open('data2.csv',newline='') as f:
    reader=csv.reader(f)
    data=list(reader)

df=pd.DataFrame(data,columns=['A','B','C','D','E','F','G','H','Class'])

##X = df.iloc[:, :-1].values
##y = df.iloc[:,-1].values
##iris = datasets.load_iris()
##
##
##X = iris.data[:, :2]
##
##y = iris.target

X = df.iloc[1:, 1:7].values
#print(X)
y = df.iloc[1:,-1].values
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, train_size=0.70, test_size=0.30, random_state=101)


rbf = svm.SVC(kernel='rbf', gamma=0.5, C=0.1).fit(X_train, y_train)
poly = svm.SVC(kernel='poly', degree=3, C=1).fit(X_train, y_train)



poly_pred = poly.predict(X_test)
rbf_pred = rbf.predict(X_test)


poly_accuracy = accuracy_score(y_test, poly_pred)
poly_f1 = f1_score(y_test, poly_pred, average='weighted')
print('Accuracy (Polynomial Kernel): ', "%.2f" % (poly_accuracy*100))
print('F1 (Polynomial Kernel): ', "%.2f" % (poly_f1*100))


