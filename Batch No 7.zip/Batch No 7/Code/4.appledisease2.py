import cv2
import numpy as np
import os
from skimage import color
from sklearn.cluster import KMeans
from skimage.feature import (graycomatrix,
                             graycoprops,
                             local_binary_pattern,
                             multiblock_lbp)
from skimage._shared.testing import test_parallel
from skimage.transform import integral_image
from skimage._shared import testing
from skimage import img_as_ubyte
import pandas as pd
from scipy.stats import skew, kurtosis

def get_textural_features(img,i):
    img = img_as_ubyte(color.rgb2gray(img))
    #ret, bw_img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
    ret,img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
    glcm = graycomatrix(img, [1], [0], 256, symmetric=True, normed=True)
    dissimilarity = graycoprops(glcm, 'dissimilarity')[0, 0]
    correlation = graycoprops(glcm, 'correlation')[0, 0]
    homogeneity = graycoprops(glcm, 'homogeneity')[0, 0]
    energy = graycoprops(glcm, 'energy')[0, 0]
    contrast=graycoprops(glcm, 'contrast')[0, 0]
    ASM=graycoprops(glcm, 'ASM')[0][0]
    
    lbp = local_binary_pattern(img, 3, 24, method="default")
    lbp_code = multiblock_lbp(img, 0, 0, 9, 9)
    sk=skew(img.reshape(-1))
    kt=kurtosis(img.reshape(-1))
    #print(lbp_code)
    
    #print(np.sum(lbp))
    feature = np.array([dissimilarity, correlation, homogeneity, energy, contrast, ASM,sk,kt,np.mean(lbp),i])
    print(feature)
    return feature

l=list()
folders=["Normal_Apple(1)","Rot_Apple(1)","Blotch_Apple(1)"]
bi=0
for folder in folders:
    bi=bi+1
    print("Processing folder.....",folder)
    for filename in os.listdir(folder):
        print("File: ",filename)
        img = cv2.imread(os.path.join(folder,filename))
        image=cv2.cvtColor(img,cv2.COLOR_BGR2LAB)
#cv2.imshow('original',lab)
        reshaped = image.reshape(image.shape[0] * image.shape[1], image.shape[2])



        numClusters = max(2, 2)
        kmeans = KMeans(n_clusters=numClusters, n_init=100, max_iter=1000).fit(reshaped)
        clustering = np.reshape(np.array(kmeans.labels_, dtype=np.uint8),
            (image.shape[0], image.shape[1]))
        sortedLabels = sorted([n for n in range(numClusters)],
            key=lambda x: -np.sum(clustering == x))
        kmeansImage = np.zeros(image.shape[:2], dtype=np.uint8)
        for i, label in enumerate(sortedLabels):
            kmeansImage[clustering == label] = int((255) / (numClusters - 1)) * i
        concatImage = np.concatenate((img,
            193 * np.ones((img.shape[0], int(0.0625 * img.shape[1]), 3), dtype=np.uint8),
            cv2.cvtColor(kmeansImage, cv2.COLOR_GRAY2BGR)), axis=1)
        #cv2.imshow('Original vs clustered', kmeansImage)
        ki=cv2.cvtColor(kmeansImage, cv2.COLOR_GRAY2BGR)
        l.append(get_textural_features(ki,bi))
        #break;
    
    
DF = pd.DataFrame(l)
  
# save the dataframe as a csv file
DF.to_csv("data1.csv")
