from sklearn import svm, datasets
import sklearn.model_selection as model_selection
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
import pandas as pd
import csv
import numpy as np
from sklearn.ensemble import RandomForestClassifier

with open('data13.csv',newline='') as f:
    reader=csv.reader(f)
    data=list(reader)

df=pd.DataFrame(data,columns=['A','B','C','D','E','F','G','H','I','J','K','L','M','Class'])

##X = df.iloc[:, :-1].values
##y = df.iloc[:,-1].values
##iris = datasets.load_iris()
##
##
##X = iris.data[:, :2]
##
##y = iris.target

X = df.iloc[1:, 1:13].values
#print(X)
y = df.iloc[1:,-1].values
# creating a RF classifier
clf = RandomForestClassifier(n_estimators = 1000) 
 
# Training the model on the training dataset
# fit function is used to train the model using the training sets as parameters
#tx=np.array([[7.466216216,0.9338643,0.970721171,0.727229541,1903.885135,0.528862805,0.688721547,-1.52566263,4.893163752,60559,20,564]])
#tx=np.array([[12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206]])
tx=np.array([[10.78987069,0.909003407,0.957687432,0.703192264,2751.417026,0.49447936,0.553223024,-1.693944286,5.598532345,53500,26,1107]])

X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, train_size=0.65, test_size=0.35, random_state=103)
clf.fit(X_train, y_train)
 
# performing predictions on the test dataset
y_pred = clf.predict(X_test)
y1_pred=clf.predict(tx)
print(y1_pred)
# metrics are used to find accuracy or error
from sklearn import metrics 
print()
 
# using metrics module for accuracy calculation
print("ACCURACY OF THE MODEL: ", metrics.accuracy_score(y_test, y_pred))
