from sklearn import svm, datasets
import sklearn.model_selection as model_selection
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
import pandas as pd
import csv
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import cv2
import numpy as np
import os
from skimage import color
from sklearn.cluster import KMeans
from skimage.feature import (graycomatrix,
                             graycoprops,
                             local_binary_pattern,
                             multiblock_lbp)
from skimage._shared.testing import test_parallel
from skimage.transform import integral_image
from skimage._shared import testing
from skimage import img_as_ubyte
import pandas as pd
from scipy.stats import skew, kurtosis
from PIL import Image, ImageFilter
import numpy as np
from itertools import product
from collections import defaultdict
import os
import cv2
from skimage import color
from PIL import ImageCms
import pandas as pd
import tkinter as tk
from tkinter import filedialog
from tkinter.filedialog import askopenfile
from tkinter import messagebox

class CCV(object):
    MAX_VALUE_PIXEL = 256
    NUM_BINS_EACH_COLOR = 4
    BIN_WIDTH = MAX_VALUE_PIXEL / NUM_BINS_EACH_COLOR
    TAU = 25

    def __init__(self, image_file):
        self.srgb_p = ImageCms.createProfile("sRGB")
        self.lab_p  = ImageCms.createProfile("LAB")
        self.rgb2lab_trans = ImageCms.buildTransformFromOpenProfiles(self.srgb_p, self.lab_p, "RGB", "LAB")
        self._im_org = Image.open(image_file)
        self._im_org = ImageCms.applyTransform(self._im_org, self.rgb2lab_trans)
        self._im_org=self._im_org.resize((256,256))
        self._w, self._h = self._im_org.size
        self._discretized_im = np.zeros((self._h, self._w), dtype=int)
        self._labeled_im = np.zeros((self._h, self._w), dtype=int)
        self._label_to_color = defaultdict(list)
        self.ccv_vector = defaultdict(list)

    def extract(self):
        self.__blur()
        self.__discretize_colorspace()
        self.__compute_connected_components()
        self.__gen_ccv_vector()

    def __blur(self):
        self._im = self._im_org.copy()

        for y in range(1, self._h-1):
            for x in range(1, self._w-1):
                adj_pixels = [self._im_org.getpixel((i, j))
                              for i in range(x-1, x+2)
                              for j in range(y-1, y+2)]

                # replace pixel value
                self._im.putpixel((x, y),
                                  tuple(
                                      map(int,
                                          np.mean(adj_pixels, 0).tolist()
                                          )
                                  ))

    def __discretize_colorspace(self):
        for y, x in product(*map(range, (self._h, self._w))):
            # idx = red_i + green_i * 4 + blue_i * 16
            idx = self.__getidx(x, y, ch=0) + \
                  self.__getidx(x, y, ch=1) + \
                  self.__getidx(x, y, ch=2)

            # assign an index of discretized colorspace
            self._discretized_im[y][x] = idx

    def __getidx(self, x, y, ch=0):
        idx = self._im.getpixel((x, y))[ch] / self.BIN_WIDTH
        return idx if ch == 0 \
            else idx * (self.NUM_BINS_EACH_COLOR ** ch)

    def __compute_connected_components(self):
        self._current_label = 0
        
        for y, x in product(*map(range, (self._h, self._w))):
            checklist, xylist = self.__get_checklist(x, y)
            current_color = self._discretized_im[y][x]

            if current_color in checklist:
                # assign same label from labeled_im
                idx = checklist.index(current_color)
                cx, cy = xylist[idx][0], xylist[idx][1]
                self._labeled_im[y][x] = self._labeled_im[cy][cx]
            else:
                # assign new label
                self._labeled_im[y][x] = self._current_label
                self._label_to_color[self._current_label] = current_color
                self._current_label += 1
                
    def __get_checklist(self, x, y):
        checklist = []
        xylist = []
        
        if x != 0 and x != self._w-1 and y != 0:
            checklist.append(self._discretized_im[y-1][x-1])
            xylist.append([x-1, y-1])
            checklist.append(self._discretized_im[y-1][x])
            xylist.append([x, y-1])
            checklist.append(self._discretized_im[y-1][x+1])
            xylist.append([x+1, y-1])
            checklist.append(self._discretized_im[y][x-1])
            xylist.append([x-1, y])
        elif x != 0 and y == 0:
            checklist.append(self._discretized_im[y][x-1])
            xylist.append([x-1, y])
        elif x == 0 and y != 0:
            checklist.append(self._discretized_im[y-1][x])
            xylist.append([x, y-1])
            checklist.append(self._discretized_im[y-1][x+1])
            xylist.append([x+1, y-1])
        elif x == self._w-1 and y != 0:
            checklist.append(self._discretized_im[y-1][x-1])
            xylist.append([x-1, y-1])
            checklist.append(self._discretized_im[y-1][x])
            xylist.append([x, y-1])
            checklist.append(self._discretized_im[y][x-1])
            xylist.append([x-1, y])

        return checklist, xylist

    def __gen_ccv_vector(self):
        for label in range(self._current_label):
            s = self._labeled_im[np.where(self._labeled_im == label)].size
            color = self._label_to_color[label]
            if s >= self.TAU:
                # coherent
                if self.ccv_vector[color]:
                    self.ccv_vector[color][0] += s
                else:
                    self.ccv_vector[color] = list((s, 0))
            else:
                # incoherent
                if self.ccv_vector[color]:
                    self.ccv_vector[color][1] += s
                else:
                    self.ccv_vector[color] = list((0, s))


def get_textural_features(img):
    img = img_as_ubyte(color.rgb2gray(img))
    #ret, bw_img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
    ret,img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
    glcm = graycomatrix(img, [1], [0], 256, symmetric=True, normed=True)
    dissimilarity = graycoprops(glcm, 'dissimilarity')[0, 0]
    correlation = graycoprops(glcm, 'correlation')[0, 0]
    homogeneity = graycoprops(glcm, 'homogeneity')[0, 0]
    energy = graycoprops(glcm, 'energy')[0, 0]
    contrast=graycoprops(glcm, 'contrast')[0, 0]
    ASM=graycoprops(glcm, 'ASM')[0][0]
    
    lbp = local_binary_pattern(img, 3, 24, method="default")
    lbp_code = multiblock_lbp(img, 0, 0, 9, 9)
    sk=skew(img.reshape(-1))
    kt=kurtosis(img.reshape(-1))
    #print(lbp_code)
    
    #print(np.sum(lbp))
    feature = np.array([dissimilarity,correlation,homogeneity,energy,contrast,ASM,sk,kt,np.mean(lbp)])
    #print(feature)
    return feature

def get_features(filename):
        l=list()
        #filename="Normal_Apple(1)/AnyConv.com__download (2)(2).jpg"
        img = cv2.imread(filename)
        image=cv2.cvtColor(img,cv2.COLOR_BGR2LAB)
#cv2.imshow('original',lab)
        reshaped = image.reshape(image.shape[0] * image.shape[1], image.shape[2])



        numClusters = max(2, 2)
        kmeans = KMeans(n_clusters=numClusters, n_init=100, max_iter=1000).fit(reshaped)
        clustering = np.reshape(np.array(kmeans.labels_, dtype=np.uint8),
            (image.shape[0], image.shape[1]))
        sortedLabels = sorted([n for n in range(numClusters)],
            key=lambda x: -np.sum(clustering == x))
        kmeansImage = np.zeros(image.shape[:2], dtype=np.uint8)
        for i, label in enumerate(sortedLabels):
            kmeansImage[clustering == label] = int((255) / (numClusters - 1)) * i
        concatImage = np.concatenate((img,
            193 * np.ones((img.shape[0], int(0.0625 * img.shape[1]), 3), dtype=np.uint8),
            cv2.cvtColor(kmeansImage, cv2.COLOR_GRAY2BGR)), axis=1)
        #cv2.imshow('Original vs clustered', kmeansImage)
        ki=cv2.cvtColor(kmeansImage, cv2.COLOR_GRAY2BGR)
        return get_textural_features(ki).tolist()
        #return l
        #break;
    
def get_ccv_features(filename):
    ccv = CCV(filename)
    l=list()
    ccv.extract()
    coherent=0
    incoherent=0
    no_of_colors=0
    max_coherent_color=0
    max_noncoherent_color=0
    for k, v in sorted(ccv.ccv_vector.items()):
        coherent+=v[0]
        incoherent+=v[1]
        no_of_colors+=1
        if max_coherent_color<v[0]:
            max_coherent_color=v[0]
        if max_noncoherent_color<v[1]:
            max_noncoherent_color=v[1]
    #return [coherent,incoherent,no_of_colors,max_coherent_color,max_noncoherent_color]
    return [coherent,no_of_colors,max_noncoherent_color]
            
    #return l

#filename="Train\Blotch Apple1/3.jpg"
ftypes1=[("JPG files","*.jpg"),("PNG files","*.png")]
filename=filedialog.askopenfilename(filetypes=ftypes1)
l1=get_features(filename)
#print(l1)
l2=get_ccv_features(filename)
#print(l2)

##
##
##
with open('data13.csv',newline='') as f:
    reader=csv.reader(f)
    data=list(reader)

df=pd.DataFrame(data,columns=['A','B','C','D','E','F','G','H','I','J','K','L','M','Class'])

X = df.iloc[:, :-1].values
y = df.iloc[:,-1].values
iris = datasets.load_iris()


X = iris.data[:, :2]

y = iris.target
X = df.iloc[1:, 1:13].values
print(X)
y = df.iloc[1:,-1].values
### creating a RF classifier
clf = RandomForestClassifier(n_estimators = 1000) 
## 
# Training the model on the training dataset
### fit function is used to train the model using the training sets as parameters
###tx=np.array([[7.466216216,0.9338643,0.970721171,0.727229541,1903.885135,0.528862805,0.688721547,-1.52566263,4.893163752,60559,20,564]])
###tx=np.array([[12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206,12.56266206]])
##
##
l=list()
for ele in l1:
    l.append(ele)
for ele in l2:
    l.append(ele)
nl=list()
nl.append(l)
print(nl)
#l.append(l1)
#l.append(l2)
tx=np.array(nl)
#tx=np.array([l1 l2])
#tx=np.array([l1,l2])
##tx=np.array([[10.78987069,0.909003407,0.957687432,0.703192264,2751.417026,0.49447936,0.553223024,-1.693944286,5.598532345,53500,26,1107]])
##
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, train_size=0.65, test_size=0.35, random_state=103)
clf.fit(X_train, y_train)
## 
### performing predictions on the test dataset
y_pred = clf.predict(X_test)
y1_pred=clf.predict(tx)
print(y1_pred)
cls=["","Normal","Rot disease","Blotch disease"]
print(cls[int(y1_pred[0])])
blotch_des='''
Apple blotch symptoms usually present as quarter inch (0.5 cm) or larger irregular areas on the surface of infected fruits. The color may be cloudy or sooty, often making the apple surface appear olive green. It’s common for smaller areas to come together to form larger, non-circular spots on the skin. Apple blotch fungus disease is sometimes accompanied by a similar fungal disease known as “flyspeck,” which will add small, raised black spots in addition to the sooty blotches.
'''
rot_des='''
Symptoms first appear as small, slightly sunken circular areas that are light to dark brown in color. On mature fruit these areas may be surrounded by a red halo. When environmental conditions are optimal, the spots can enlarge rapidly and cover the entire fruit surface. 
The most common causes of apple rot are from the fungi Penicillium expansum and Monilinia fructigena. These fungi feed on and kill the cells that make up the apple. The fungi produce pectic enzymes that break down apple pectin to expose the nutrients of the cells to the fungi.
'''
des=["","Normal apple fairly round and some shade of red or yellow.",rot_des,blotch_des]
pest=["","No pesticide required","Thiophanate-Methyl","kresoxim methyl or trifloxystrobin"]
messagebox.showinfo("Prediction","Predicted class "+cls[int(y1_pred[0])]+" Description: "+des[int(y1_pred[0])]+"\nPesticide: "+pest[int(y1_pred[0])])

### metrics are used to find accuracy or error
from sklearn import metrics 
print()
## 
### using metrics module for accuracy calculation
print("ACCURACY OF THE MODEL: ", metrics.accuracy_score(y_test, y_pred))
